ALTER TABLE `#__guidedtour_steps` ADD COLUMN `params` text NULL /** CAN FAIL **/;
