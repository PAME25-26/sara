ALTER TABLE `#__fields` MODIFY `fieldparams` MEDIUMTEXT NOT NULL;
